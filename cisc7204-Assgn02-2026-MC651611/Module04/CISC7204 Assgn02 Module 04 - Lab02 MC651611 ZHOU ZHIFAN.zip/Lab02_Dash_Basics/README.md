# Module 04 Lab 02 - Dash Basics

CISC7204 Assignment 02 | ZHOU ZHIFAN | MC651611

## What this app does

Reads the airline reporting dataset, takes a fixed 500-row sample
(`random_state=42`), and renders one pie chart showing the proportion of
flights in each 250-mile distance group.

## How to run

```
pip install pandas dash plotly
python dash_basics.py
```

Then open http://127.0.0.1:8050/ in a browser.
