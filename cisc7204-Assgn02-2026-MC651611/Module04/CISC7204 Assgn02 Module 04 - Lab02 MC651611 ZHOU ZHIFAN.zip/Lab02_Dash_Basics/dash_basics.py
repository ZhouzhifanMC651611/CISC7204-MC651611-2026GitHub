"""CISC7204 Assignment 02 - Module 04 Lab 02: Dash Basics.

Author : ZHOU ZHIFAN
ID     : MC651611

Builds a one-page Dash application that shows the proportion of each
distance group (250 mile intervals) in a 500-row sample of the airline data.
"""

import pandas as pd
import plotly.express as px
import dash
from dash import dcc
from dash import html

# Read the airline data into a pandas dataframe
airline_data = pd.read_csv(
    'https://cf-courses-data.s3.us.cloud-object-storage.appdomain.cloud/'
    'IBMDeveloperSkillsNetwork-DV0101EN-SkillsNetwork/Data%20Files/airline_data.csv',
    encoding='ISO-8859-1',
    dtype={'Div1Airport': str, 'Div1TailNum': str,
           'Div2Airport': str, 'Div2TailNum': str})

# Randomly sample 500 data points. The random state is fixed so that the
# sample - and therefore the pie chart - is the same on every run.
data = airline_data.sample(n=500, random_state=42)

# Pie Chart Creation
fig = px.pie(data, values='Flights', names='DistanceGroup',
             title='Distance group proportion by flights')

# Create a dash application
app = dash.Dash(__name__)

# Get the layout of the application and adjust it
app.layout = html.Div(children=[
    html.H1('Airline Dashboard',
            style={'textAlign': 'center', 'color': '#503D36', 'font-size': 40}),
    html.P('Proportion of distance group (250 mile distance interval group) by flights.',
           style={'textAlign': 'center', 'color': '#F57241'}),
    dcc.Graph(figure=fig),
])

# Run the application
if __name__ == '__main__':
    app.run(debug=True)
