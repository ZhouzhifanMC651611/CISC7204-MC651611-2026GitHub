# Module 04 Lab 03 - Add Interactivity

CISC7204 Assignment 02 | ZHOU ZHIFAN | MC651611

## Files

| File | What it is |
|---|---|
| `dash_interactivity.py` | Main lab: a year input drives a line plot of the average arrival delay by month. |
| `dash_interactivity_barplot.py` | Practice exercise: the same callback pattern, with a bar chart of flights by destination state and reporting airline. |

## How to run

```
pip install pandas dash plotly
python dash_interactivity.py
```

or

```
python dash_interactivity_barplot.py
```

Then open http://127.0.0.1:8050/ and change the year to see the callback run.
