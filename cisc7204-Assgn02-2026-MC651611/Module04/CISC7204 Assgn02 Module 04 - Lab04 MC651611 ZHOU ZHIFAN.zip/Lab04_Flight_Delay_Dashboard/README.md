# Module 04 Lab 04 - Flight Delay Time Statistics Dashboard

CISC7204 Assignment 02 | ZHOU ZHIFAN | MC651611

## What this app does

One year input drives five linked charts: carrier delay, weather delay, NAS
delay, security delay and late aircraft delay, each averaged by month and
split by reporting airline. `compute_info()` does the aggregation and a single
callback returns all five figures.

## How to run

```
pip install pandas dash plotly
python flight_delay.py
```

Then open http://127.0.0.1:8050/ and change the year.
