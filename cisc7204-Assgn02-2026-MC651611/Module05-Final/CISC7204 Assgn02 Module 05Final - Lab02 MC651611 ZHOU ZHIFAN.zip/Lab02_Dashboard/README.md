# Module 05 Final Project, Lab 02 - Dashboard

CISC7204 Assignment 02 | ZHOU ZHIFAN | MC651611

One Dash page, two report types, both driven by the same year dropdown
(2005 to 2020).

| Report type | Charts |
|---|---|
| Yearly Airline Performance Report | treemap of destination states, pie of diverted landings by airline, choropleth of flights by origin state, bar of monthly cancellations, line of average air time |
| Yearly Average Flight Delay Statistics | five line charts: carrier, weather, NAS, security and late aircraft delay |

## How to run

```
pip install pandas dash plotly
python airline_performance_dashboard.py
```

Then open http://127.0.0.1:8050/ and choose a report type and a year.
