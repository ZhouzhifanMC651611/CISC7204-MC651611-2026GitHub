"""CISC7204 Assignment 02 - Module 05 Practice Project, Lab 02 (part 2).

Author : ZHOU ZHIFAN
ID     : MC651611

The practice exercise: one dropdown selects the drive wheel type, and a
callback returns a pie chart and a bar chart of the average price by body
style for that selection.
"""

import pandas as pd
import dash
from dash import dcc
from dash import html
from dash.dependencies import Input, Output, State
import plotly.express as px

app = dash.Dash(__name__)

# Do not raise callback exceptions before the first callback has run
app.config.suppress_callback_exceptions = True

# Read the automobiles data into a pandas dataframe
auto_data = pd.read_csv('automobileEDA.csv', encoding='ISO-8859-1')

app.layout = html.Div(children=[
    html.H1('Car Automobile Components',
            style={'textAlign': 'center', 'color': '#503D36', 'font-size': 24}),

    # Outer division
    html.Div([
        # Helper text for the dropdown
        html.Div(html.H2('Drive Wheels Type:', style={'margin-right': '2em'})),

        dcc.Dropdown(
            id='demo-dropdown',
            options=[
                {'label': 'Rear Wheel Drive', 'value': 'rwd'},
                {'label': 'Front Wheel Drive', 'value': 'fwd'},
                {'label': 'Four Wheel Drive', 'value': '4wd'},
            ],
            value='rwd'
        ),

        # Two empty divisions filled by the callback
        html.Div([
            html.Div([], id='plot1'),
            html.Div([], id='plot2'),
        ], style={'display': 'flex'}),
    ])
])


@app.callback([Output(component_id='plot1', component_property='children'),
               Output(component_id='plot2', component_property='children')],
              Input(component_id='demo-dropdown', component_property='value'))
def display_selected_drive_charts(value):
    # Average price by body style for the selected drive wheel type
    filtered_df = auto_data[auto_data['drive-wheels'] == value].groupby(
        ['drive-wheels', 'body-style'], as_index=False).mean(numeric_only=True)

    fig1 = px.pie(filtered_df, values='price', names='body-style', title='Pie Chart')
    fig2 = px.bar(filtered_df, x='body-style', y='price', title='Bar Chart')

    return [dcc.Graph(figure=fig1), dcc.Graph(figure=fig2)]


if __name__ == '__main__':
    app.run(debug=True)
