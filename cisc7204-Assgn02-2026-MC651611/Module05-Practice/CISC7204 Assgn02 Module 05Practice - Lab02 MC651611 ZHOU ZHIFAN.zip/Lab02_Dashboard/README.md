# Module 05 Practice Project, Lab 02 - Creating Dashboards

CISC7204 Assignment 02 | ZHOU ZHIFAN | MC651611

| File | What it is |
|---|---|
| `dash_layout.py` | Part 1: the layout lab - title, dropdown and grouped bar chart. |
| `Dash_Auto.py` | Part 2: the practice exercise - a drive-wheels dropdown drives a pie chart and a bar chart of average price by body style. |
| `automobileEDA.csv` | The automobile dataset used by `Dash_Auto.py`. |

## How to run

```
pip install pandas dash plotly
python Dash_Auto.py
```

Then open http://127.0.0.1:8050/ and change the drive wheels type.
