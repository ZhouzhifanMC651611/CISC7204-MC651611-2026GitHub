"""CISC7204 Assignment 02 - Module 05 Practice Project, Lab 02 (part 1).

Author : ZHOU ZHIFAN
ID     : MC651611

The layout lab: a title, a dropdown and a grouped bar chart, built up with
html.Div / html.H1 and dcc.Dropdown / dcc.Graph.
"""

import pandas as pd
import dash
from dash import dcc
from dash import html
import plotly.express as px

# Dataframe used by the layout example
df = pd.DataFrame({
    "Fruit": ["Apples", "Oranges", "Bananas", "Apples", "Oranges", "Bananas"],
    "Amount": [4, 1, 2, 2, 4, 5],
    "City": ["SF", "SF", "SF", "NYC", "MTL", "NYC"]
})

# Bar graph figure
fig = px.bar(df, x="Fruit", y="Amount", color="City", barmode="group")

app = dash.Dash(__name__)

# Create the layout
app.layout = html.Div(children=[
    html.H1(children='Dashboard', style={'textAlign': 'center'}),

    # Dropdown
    dcc.Dropdown(options=[
        {'label': 'New York City', 'value': 'NYC'},
        {'label': 'Montréal', 'value': 'MTL'},
        {'label': 'San Francisco', 'value': 'SF'}
    ], value='NYC'),

    # Bar graph
    dcc.Graph(id='example-graph-2', figure=fig)
])

if __name__ == '__main__':
    app.run(debug=True)
